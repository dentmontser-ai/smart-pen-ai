# دليل النشر على Netlify

## متطلبات النشر

### 1. متطلبات Netlify
- حساب Netlify مجاني
- Git repository (GitHub, GitLab, Bitbucket)
- Node.js و pnpm مثبتة

### 2. متطلبات قاعدة البيانات
هذا المشروع يحتاج إلى قاعدة بيانات MySQL/TiDB:
- يمكنك استخدام خدمات مجانية مثل:
  - **PlanetScale** (MySQL مجاني)
  - **Railway** (قاعدة بيانات مجانية)
  - **Render** (PostgreSQL مجاني)

### 3. متطلبات OAuth
المشروع يستخدم Manus OAuth:
- تأكد من إعدادات OAuth في Manus
- احصل على `VITE_APP_ID` من Manus

## خطوات النشر

### الخطوة 1: إعداد قاعدة البيانات
```bash
# 1. احصل على DATABASE_URL من خدمة قاعدة البيانات
# 2. أضف المتغيرات البيئية في Netlify
```

### الخطوة 2: ربط مع Netlify
```bash
# 1. ادفع الملفات إلى GitHub
git push origin main

# 2. اذهب إلى https://app.netlify.com
# 3. اضغط "New site from Git"
# 4. اختر repository
# 5. اضغط "Deploy"
```

### الخطوة 3: إضافة متغيرات البيئة
في لوحة تحكم Netlify:
1. اذهب إلى **Site settings**
2. اختر **Build & deploy** → **Environment**
3. أضف المتغيرات التالية:

```
DATABASE_URL = mysql://...
JWT_SECRET = your-secret-key
VITE_APP_ID = your-app-id
OAUTH_SERVER_URL = https://api.manus.im
VITE_OAUTH_PORTAL_URL = https://manus.im/oauth
OWNER_NAME = Your Name
OWNER_OPEN_ID = your-id
BUILT_IN_FORGE_API_URL = https://api.manus.im
BUILT_IN_FORGE_API_KEY = your-key
VITE_FRONTEND_FORGE_API_URL = https://api.manus.im
VITE_FRONTEND_FORGE_API_KEY = your-key
VITE_APP_TITLE = Smart Pen AI
VITE_APP_LOGO = https://...
```

### الخطوة 4: تشغيل البناء
```bash
# Netlify ستشغل تلقائياً:
pnpm install
pnpm build
```

## ملاحظات مهمة

⚠️ **تحذير:** Netlify توفر استضافة Frontend فقط. 
- Backend (Express + tRPC) قد لا يعمل بالكامل على Netlify
- للحصول على Backend كامل، استخدم Manus أو منصات أخرى مثل Railway/Render

## البدائل الأفضل

### 1. Manus (الأفضل)
- ✅ Frontend + Backend معاً
- ✅ قاعدة بيانات مجانية
- ✅ تخزين ملفات مجاني
- ✅ بدون تكاليف

### 2. Railway
- ✅ Frontend + Backend
- ✅ قاعدة بيانات مجانية
- ✅ سهل الاستخدام

### 3. Render
- ✅ Frontend + Backend
- ✅ قاعدة بيانات مجانية
- ✅ مجاني تماماً

## استكشاف الأخطاء

### خطأ: "Netlify Functions not found"
- تأكد من وجود ملف `netlify.toml`
- تحقق من إعدادات البناء

### خطأ: "Database connection failed"
- تحقق من `DATABASE_URL` في متغيرات البيئة
- تأكد من صحة بيانات الاتصال

### خطأ: "OAuth not working"
- تحقق من `VITE_APP_ID` و `OAUTH_SERVER_URL`
- تأكد من إعدادات OAuth في Manus

## الدعم

للمزيد من المساعدة:
- 📖 [Netlify Documentation](https://docs.netlify.com)
- 🔧 [Manus Documentation](https://manus.im/docs)
- 💬 [Community Support](https://community.manus.im)
