import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Orders table - stores all incoming requests from users
 */
export const orders = mysqlTable("orders", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").references(() => users.id),
  serviceType: varchar("serviceType", { length: 100 }).notNull(), // e.g., "graduation_project", "test_solutions", "summary"
  language: varchar("language", { length: 50 }).default("ar").notNull(), // ar, en
  fileFormat: varchar("fileFormat", { length: 50 }).notNull(), // docx, pptx, pdf
  deliveryDate: timestamp("deliveryDate"),
  details: text("details").notNull(), // Full order description
  attachmentUrl: text("attachmentUrl"), // URL to uploaded file (if any)
  attachmentFileName: varchar("attachmentFileName", { length: 255 }),
  status: mysqlEnum("status", ["received", "processing", "completed", "failed"]).default("received").notNull(),
  userEmail: varchar("userEmail", { length: 320 }),
  userPhone: varchar("userPhone", { length: 20 }),
  userName: varchar("userName", { length: 255 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Order = typeof orders.$inferSelect;
export type InsertOrder = typeof orders.$inferInsert;

/**
 * Generated Content table - stores AI-generated academic content
 */
export const generatedContent = mysqlTable("generatedContent", {
  id: int("id").autoincrement().primaryKey(),
  orderId: int("orderId").notNull().references(() => orders.id),
  content: text("content").notNull(), // Raw content from AI
  contentType: varchar("contentType", { length: 50 }).notNull(), // text, markdown, html
  aiModel: varchar("aiModel", { length: 100 }).default("gpt-4"),
  tokensUsed: int("tokensUsed"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type GeneratedContent = typeof generatedContent.$inferSelect;
export type InsertGeneratedContent = typeof generatedContent.$inferInsert;

/**
 * Files table - stores information about generated files
 */
export const files = mysqlTable("files", {
  id: int("id").autoincrement().primaryKey(),
  orderId: int("orderId").notNull().references(() => orders.id),
  fileKey: varchar("fileKey", { length: 500 }).notNull(), // S3 key for the file
  fileUrl: text("fileUrl").notNull(), // Public URL to download
  fileName: varchar("fileName", { length: 255 }).notNull(),
  fileFormat: varchar("fileFormat", { length: 50 }).notNull(), // docx, pptx, pdf
  fileSizeBytes: int("fileSizeBytes"),
  mimeType: varchar("mimeType", { length: 100 }),
  expiresAt: timestamp("expiresAt"), // When the download link expires
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type File = typeof files.$inferSelect;
export type InsertFile = typeof files.$inferInsert;

/**
 * Order Status History - tracks status changes for each order
 */
export const orderStatusHistory = mysqlTable("orderStatusHistory", {
  id: int("id").autoincrement().primaryKey(),
  orderId: int("orderId").notNull().references(() => orders.id),
  previousStatus: varchar("previousStatus", { length: 50 }),
  newStatus: varchar("newStatus", { length: 50 }).notNull(),
  reason: text("reason"), // Why the status changed
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type OrderStatusHistory = typeof orderStatusHistory.$inferSelect;
export type InsertOrderStatusHistory = typeof orderStatusHistory.$inferInsert;