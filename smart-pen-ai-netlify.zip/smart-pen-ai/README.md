# Smart Pen AI - منصة الخدمات الأكاديمية الذكية

🎓 منصة ويب متكاملة لتوليد المحتوى الأكاديمي الذكي بالعربية

## المميزات الرئيسية

✨ **واجهة طلب ذكية**
- نموذج طلب متقدم بالعربية
- دعم كامل لـ RTL
- تصميم احترافي بنفسجي وذهبي

🤖 **توليد محتوى أكاديمي**
- أبحاث علمية
- عروض تقديمية
- ملخصات
- حلول اختبارات
- مقالات
- مخططات

📄 **توليد ملفات**
- Word (DOCX)
- PDF
- PowerPoint (PPTX)

👨‍💼 **لوحة تحكم المالك**
- عرض جميع الطلبات
- إحصائيات سريعة
- تحديث حالة الطلب
- تحميل الملفات

🔔 **نظام الإشعارات**
- إشعارات فورية للمالك
- تفاصيل الطلب الكاملة

💰 **مجاني بالكامل**
- استضافة مجانية
- قاعدة بيانات مجانية
- تخزين ملفات مجاني
- بدون تكاليف إضافية

## التكنولوجيا المستخدمة

### Frontend
- **React 19** - مكتبة واجهات المستخدم
- **Tailwind CSS 4** - تصميم احترافي
- **TypeScript** - لغة برمجة آمنة
- **tRPC** - اتصال آمن مع الخادم

### Backend
- **Express 4** - خادم ويب
- **tRPC 11** - API آمن
- **Drizzle ORM** - قاعدة بيانات
- **MySQL/TiDB** - قاعدة بيانات

### أدوات إضافية
- **docx** - توليد ملفات Word
- **pdfkit** - توليد ملفات PDF
- **Vitest** - اختبارات

## البدء السريع

### المتطلبات
- Node.js 18+
- pnpm (أو npm/yarn)
- قاعدة بيانات MySQL

### التثبيت

```bash
# 1. استخراج الملفات
unzip smart-pen-ai.zip
cd smart-pen-ai

# 2. تثبيت المكتبات
pnpm install

# 3. إعداد قاعدة البيانات
# أضف DATABASE_URL في .env

# 4. تشغيل الخادم
pnpm dev
```

### الوصول للموقع
```
http://localhost:3000
```

## الملفات الرئيسية

```
smart-pen-ai/
├── client/                    # Frontend
│   ├── src/
│   │   ├── pages/            # صفحات التطبيق
│   │   │   ├── OrderPage.tsx  # صفحة الطلب
│   │   │   └── AdminDashboard.tsx # لوحة التحكم
│   │   ├── components/       # مكونات React
│   │   └── lib/              # مكتبات مساعدة
│   └── index.html
├── server/                    # Backend
│   ├── routers.ts            # API endpoints
│   ├── db.ts                 # دوال قاعدة البيانات
│   ├── storage.ts            # تخزين الملفات
│   └── _core/
│       ├── contentGeneration.ts # توليد المحتوى
│       └── fileGeneration.ts    # توليد الملفات
├── drizzle/                   # قاعدة البيانات
│   ├── schema.ts             # هيكل الجداول
│   └── migrations/           # ترحيلات قاعدة البيانات
├── netlify.toml              # إعدادات Netlify
├── vercel.json               # إعدادات Vercel
└── DEPLOYMENT.md             # دليل النشر
```

## إعدادات قاعدة البيانات

### الجداول الرئيسية

**orders** - الطلبات الواردة
```sql
- id (PK)
- userName
- userEmail
- serviceType
- language
- fileFormat
- details
- status
- createdAt
- updatedAt
```

**generated_content** - المحتوى المُولّد
```sql
- id (PK)
- orderId (FK)
- contentType
- title
- content
- createdAt
```

**files** - الملفات المُولّدة
```sql
- id (PK)
- orderId (FK)
- fileName
- fileUrl
- fileFormat
- fileSize
- createdAt
```

**order_status_history** - سجل حالات الطلب
```sql
- id (PK)
- orderId (FK)
- status
- changedAt
```

## النشر

### على Netlify
```bash
# 1. ادفع الملفات إلى GitHub
git push origin main

# 2. اذهب إلى https://app.netlify.com
# 3. اضغط "New site from Git"
# 4. أضف متغيرات البيئة
# 5. انتظر اكتمال البناء
```

### على Manus (الأفضل)
```bash
# 1. انقر "Publish" في لوحة التحكم
# 2. اختر اسم النطاق
# 3. انتظر اكتمال النشر
```

### على Railway أو Render
```bash
# اتبع الخطوات المشابهة لـ Netlify
# مع إضافة قاعدة البيانات
```

## الاستخدام

### للعملاء
1. اذهب إلى الصفحة الرئيسية
2. املأ نموذج الطلب
3. اختر نوع الخدمة
4. أرسل الطلب
5. انتظر الإشعار بالملف الجاهز

### للمالك
1. اذهب إلى `/admin`
2. شاهد جميع الطلبات
3. راجع التفاصيل
4. حدّث حالة الطلب
5. حمّل الملفات

## المتغيرات البيئية المطلوبة

```
DATABASE_URL              # رابط قاعدة البيانات
JWT_SECRET               # مفتاح التوقيع
VITE_APP_ID             # معرف التطبيق
OAUTH_SERVER_URL        # خادم OAuth
VITE_OAUTH_PORTAL_URL   # بوابة OAuth
OWNER_NAME              # اسم المالك
OWNER_OPEN_ID           # معرف المالك
BUILT_IN_FORGE_API_URL  # API الخدمات المدمجة
BUILT_IN_FORGE_API_KEY  # مفتاح API
VITE_APP_TITLE          # عنوان التطبيق
VITE_APP_LOGO           # شعار التطبيق
```

## الاختبارات

```bash
# تشغيل الاختبارات
pnpm test

# اختبار ملف معين
pnpm test server/auth.logout.test.ts

# مع التغطية
pnpm test --coverage
```

## استكشاف الأخطاء

### مشكلة: الموقع لا يحمل
- تحقق من أن الخادم يعمل: `pnpm dev`
- تحقق من متصفحك: استخدم Chrome أو Firefox الأحدث

### مشكلة: قاعدة البيانات لا تتصل
- تحقق من `DATABASE_URL`
- تأكد من أن قاعدة البيانات تعمل
- شغّل الترحيل: `pnpm drizzle-kit generate`

### مشكلة: الإشعارات لا تصل
- تحقق من `BUILT_IN_FORGE_API_KEY`
- تأكد من إعدادات الإشعارات في Manus

## المساهمة

نرحب بالمساهمات! يرجى:
1. Fork المشروع
2. إنشاء branch جديد
3. إرسال Pull Request

## الترخيص

هذا المشروع مرخص تحت MIT License

## الدعم والتواصل

- 📧 البريد الإلكتروني: support@smartpen.ai
- 💬 وسائل التواصل الاجتماعي: @smartpenai
- 📖 الوثائق: https://docs.smartpen.ai

## شكراً لاستخدامك Smart Pen AI! 🎉

---

**آخر تحديث:** 2026-04-16
**الإصدار:** 1.0.0
