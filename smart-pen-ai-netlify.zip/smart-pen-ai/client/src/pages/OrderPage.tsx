import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card } from "@/components/ui/card";
import { AlertCircle, CheckCircle2, Loader2, Paperclip } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

/**
 * Smart Pen Order Page - واجهة الطلب الذكية
 * تصميم مستوحى من index2.html مع الألوان البنفسجية والذهبية
 */
export default function OrderPage() {
  const [formData, setFormData] = useState({
    serviceType: "",
    language: "",
    fileFormat: "",
    details: "",
    userName: "",
    userEmail: "",
    userPhone: "",
  });

  const [attachedFile, setAttachedFile] = useState<File | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const submitOrderMutation = trpc.orders.submitOrder.useMutation({
    onSuccess: (data: any) => {
      toast.success("تم استقبال طلبك بنجاح! سيتم معالجته قريباً.");
      setFormData({
        serviceType: "",
        language: "",
        fileFormat: "",
        details: "",
        userName: "",
        userEmail: "",
        userPhone: "",
      });
      setAttachedFile(null);
      setIsSubmitting(false);
    },
    onError: (error: any) => {
      toast.error("حدث خطأ في إرسال الطلب. يرجى المحاولة مجدداً.");
      setIsSubmitting(false);
    },
  });

  const serviceOptions = [
    "مشروع تخرج",
    "حل اختبارات",
    "حل كويزات",
    "إعادة صياغة",
    "تدقيق لغوي",
    "تصميم سيرة ذاتية",
    "تلخيص",
    "ترجمة",
    "كتابة محتوى",
    "تحليل بيانات",
  ];

  const languageOptions = ["عربي", "إنجليزي", "عربي وإنجليزي"];

  const fileFormatOptions = ["Word (DOCX)", "PDF", "PowerPoint (PPTX)", "Excel (XLSX)"];

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.serviceType) newErrors.serviceType = "اختر نوع الخدمة";
    if (!formData.language) newErrors.language = "اختر اللغة";
    if (!formData.fileFormat) newErrors.fileFormat = "اختر صيغة الملف";
    if (!formData.details.trim()) newErrors.details = "أدخل تفاصيل الطلب";
    if (!formData.userName.trim()) newErrors.userName = "أدخل اسمك";
    if (!formData.userEmail.trim()) newErrors.userEmail = "أدخل بريدك الإلكتروني";
    if (!formData.userPhone.trim()) newErrors.userPhone = "أدخل رقم هاتفك";

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) {
      toast.error("يرجى ملء جميع الحقول المطلوبة");
      return;
    }

    setIsSubmitting(true);

    try {
      await submitOrderMutation.mutateAsync({
        serviceType: formData.serviceType,
        language: formData.language,
        fileFormat: formData.fileFormat,
        details: formData.details,
        userName: formData.userName,
        userEmail: formData.userEmail,
        userPhone: formData.userPhone,
        attachmentFileName: attachedFile?.name,
      });
    } catch (error) {
      console.error("Error submitting order:", error);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setAttachedFile(e.target.files[0]);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-[#7B68EE] to-[#483D8B]" dir="rtl">
      {/* Hero Section */}
      <div className="flex-shrink-0 py-8 px-4 text-center text-white">
        <div className="mb-4 flex justify-center">
          <svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-20 h-20">
            <path d="M50 10L55 25H45L50 10Z" fill="#FFD700" />
            <circle cx="50" cy="35" r="15" stroke="#FFD700" strokeWidth="3" />
            <path d="M45 35H55M50 30V40" stroke="#FFD700" strokeWidth="2" />
            <path d="M35 55L50 90L65 55C65 55 60 45 50 45C40 45 35 55 35 55Z" fill="#2c3e50" />
            <circle cx="50" cy="65" r="3" fill="#FFD700" />
            <line x1="50" y1="10" x2="50" y2="5" stroke="#FFD700" strokeWidth="2" />
            <line x1="65" y1="20" x2="70" y2="15" stroke="#FFD700" strokeWidth="2" />
            <line x1="35" y1="20" x2="30" y2="15" stroke="#FFD700" strokeWidth="2" />
          </svg>
        </div>
        <h1 className="text-5xl font-bold mb-2" style={{ fontFamily: "'Dancing Script', cursive", color: "#FFD700" }}>
          Smart Pen
        </h1>
        <p className="text-lg tracking-widest opacity-90">ACADEMIC SERVICES</p>
        <p className="text-lg font-bold mt-2" style={{ color: "#FFD700" }}>
          شريكك الموثوق في رحلتك الأكاديمية
        </p>
      </div>

      {/* Form Section */}
      <div className="flex-1 bg-white rounded-t-3xl shadow-lg overflow-y-auto px-4 py-6">
        <div className="max-w-2xl mx-auto">
          <h2 className="text-2xl font-bold text-center mb-6 text-gray-800">تفاصيل الطلب الكاملة</h2>

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Service Type */}
            <div>
              <label className="block text-sm font-bold text-gray-700 mb-2">نوع الخدمة المطلوبة *</label>
              <Select value={formData.serviceType} onValueChange={(value) => setFormData({ ...formData, serviceType: value })}>
                <SelectTrigger className="w-full border-2 border-gray-300 rounded-lg">
                  <SelectValue placeholder="اختر نوع الخدمة" />
                </SelectTrigger>
                <SelectContent>
                  {serviceOptions.map((service) => (
                    <SelectItem key={service} value={service}>
                      {service}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {errors.serviceType && <p className="text-red-500 text-sm mt-1">{errors.serviceType}</p>}
            </div>

            {/* Language and File Format */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2">لغة العمل *</label>
                <Select value={formData.language} onValueChange={(value) => setFormData({ ...formData, language: value })}>
                  <SelectTrigger className="w-full border-2 border-gray-300 rounded-lg">
                    <SelectValue placeholder="اختر اللغة" />
                  </SelectTrigger>
                  <SelectContent>
                    {languageOptions.map((lang) => (
                      <SelectItem key={lang} value={lang}>
                        {lang}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {errors.language && <p className="text-red-500 text-sm mt-1">{errors.language}</p>}
              </div>

              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2">صيغة الملف المطلوبة *</label>
                <Select value={formData.fileFormat} onValueChange={(value) => setFormData({ ...formData, fileFormat: value })}>
                  <SelectTrigger className="w-full border-2 border-gray-300 rounded-lg">
                    <SelectValue placeholder="اختر صيغة الملف" />
                  </SelectTrigger>
                  <SelectContent>
                    {fileFormatOptions.map((format) => (
                      <SelectItem key={format} value={format}>
                        {format}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {errors.fileFormat && <p className="text-red-500 text-sm mt-1">{errors.fileFormat}</p>}
              </div>
            </div>

            {/* Details */}
            <div>
              <label className="block text-sm font-bold text-gray-700 mb-2">تفاصيل الطلب *</label>
              <div className="relative">
                <Textarea
                  value={formData.details}
                  onChange={(e) => setFormData({ ...formData, details: e.target.value })}
                  placeholder="الرجاء ذكر تفاصيل الطلب وعدد الصفحات أو الشرائح وطريقة التنسيق والألوان المطلوبة..."
                  className="w-full h-32 p-4 pr-14 border-2 border-gray-300 rounded-lg font-cairo resize-none"
                />
                <label htmlFor="file-input" className="absolute bottom-3 left-3 cursor-pointer text-2xl hover:opacity-70">
                  📎
                </label>
                <input
                  id="file-input"
                  type="file"
                  onChange={handleFileChange}
                  className="hidden"
                  accept=".pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.txt,.jpg,.jpeg,.png"
                />
              </div>
              {attachedFile && (
                <div className="mt-2 flex items-center gap-2 text-green-600">
                  <CheckCircle2 className="w-4 h-4" />
                  <span className="text-sm">تم تحميل: {attachedFile.name}</span>
                </div>
              )}
              {errors.details && <p className="text-red-500 text-sm mt-1">{errors.details}</p>}
            </div>

            {/* Contact Information */}
            <div className="bg-gray-50 p-4 rounded-lg space-y-4">
              <h3 className="font-bold text-gray-800 mb-4">معلومات التواصل *</h3>

              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2">اسمك الكامل *</label>
                <Input
                  type="text"
                  value={formData.userName}
                  onChange={(e) => setFormData({ ...formData, userName: e.target.value })}
                  placeholder="أدخل اسمك الكامل"
                  className="w-full border-2 border-gray-300 rounded-lg"
                />
                {errors.userName && <p className="text-red-500 text-sm mt-1">{errors.userName}</p>}
              </div>

              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2">البريد الإلكتروني *</label>
                <Input
                  type="email"
                  value={formData.userEmail}
                  onChange={(e) => setFormData({ ...formData, userEmail: e.target.value })}
                  placeholder="your@email.com"
                  className="w-full border-2 border-gray-300 rounded-lg"
                />
                {errors.userEmail && <p className="text-red-500 text-sm mt-1">{errors.userEmail}</p>}
              </div>

              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2">رقم الهاتف *</label>
                <Input
                  type="tel"
                  value={formData.userPhone}
                  onChange={(e) => setFormData({ ...formData, userPhone: e.target.value })}
                  placeholder="+966 50 000 0000"
                  className="w-full border-2 border-gray-300 rounded-lg"
                />
                {errors.userPhone && <p className="text-red-500 text-sm mt-1">{errors.userPhone}</p>}
              </div>
            </div>

            {/* Submit Button */}
            <div className="flex justify-center pt-4">
              <Button
                type="submit"
                disabled={isSubmitting}
                className="w-full md:w-64 h-14 bg-[#7B68EE] hover:bg-[#483D8B] text-white font-bold text-lg rounded-full shadow-lg transition-all"
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="w-5 h-5 ml-2 animate-spin" />
                    جاري الإرسال...
                  </>
                ) : (
                  "تأكيد الطلب"
                )}
              </Button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
