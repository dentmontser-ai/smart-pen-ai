import { useAuth } from "@/_core/hooks/useAuth";
import { useEffect, useState } from "react";
import { Loader2, CheckCircle2, Clock, AlertCircle, Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";

/**
 * Admin Dashboard - لوحة تحكم المالك
 * إدارة الطلبات وحالتها والملفات المُولّدة
 */
export default function AdminDashboard() {
  const { user, loading: authLoading, isAuthenticated } = useAuth();
  const [selectedOrder, setSelectedOrder] = useState<any>(null);

  // في الإنتاج، سيتم استخدام tRPC للحصول على الطلبات
  // const { data: orders } = trpc.admin.getAllOrders.useQuery();

  // بيانات وهمية للاختبار
  const [orders] = useState([
    {
      id: 1,
      userName: "أحمد محمد",
      userEmail: "ahmed@example.com",
      serviceType: "مشروع تخرج",
      status: "processing",
      createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000),
      details: "مشروع في علوم الحاسوب",
    },
    {
      id: 2,
      userName: "فاطمة علي",
      userEmail: "fatima@example.com",
      serviceType: "حل اختبارات",
      status: "completed",
      createdAt: new Date(Date.now() - 24 * 60 * 60 * 1000),
      details: "اختبار الرياضيات",
    },
    {
      id: 3,
      userName: "محمود حسن",
      userEmail: "mahmoud@example.com",
      serviceType: "تدقيق لغوي",
      status: "received",
      createdAt: new Date(),
      details: "تدقيق رسالة ماجستير",
    },
  ]);

  if (authLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-[#7B68EE]" />
      </div>
    );
  }

  if (!isAuthenticated || user?.role !== "admin") {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-50">
        <Card className="p-8 text-center">
          <AlertCircle className="w-12 h-12 mx-auto mb-4 text-red-500" />
          <h1 className="text-2xl font-bold mb-2">غير مصرح</h1>
          <p className="text-gray-600">أنت لا تملك صلاحية الوصول إلى لوحة التحكم</p>
        </Card>
      </div>
    );
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "received":
        return "bg-blue-100 text-blue-800";
      case "processing":
        return "bg-yellow-100 text-yellow-800";
      case "completed":
        return "bg-green-100 text-green-800";
      case "failed":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "received":
        return <Clock className="w-4 h-4" />;
      case "processing":
        return <Loader2 className="w-4 h-4 animate-spin" />;
      case "completed":
        return <CheckCircle2 className="w-4 h-4" />;
      case "failed":
        return <AlertCircle className="w-4 h-4" />;
      default:
        return null;
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "received":
        return "مستقبل";
      case "processing":
        return "قيد المعالجة";
      case "completed":
        return "مكتمل";
      case "failed":
        return "فشل";
      default:
        return status;
    }
  };

  const formatDate = (date: Date) => {
    return new Date(date).toLocaleString("ar-SA");
  };

  return (
    <div className="min-h-screen bg-gray-50" dir="rtl">
      {/* Header */}
      <div className="bg-gradient-to-r from-[#7B68EE] to-[#483D8B] text-white p-6">
        <h1 className="text-3xl font-bold mb-2">لوحة تحكم المالك</h1>
        <p className="opacity-90">إدارة الطلبات والخدمات الأكاديمية</p>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto p-6">
        {/* Statistics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <Card className="p-4">
            <div className="text-2xl font-bold text-[#7B68EE]">{orders.length}</div>
            <p className="text-gray-600 text-sm">إجمالي الطلبات</p>
          </Card>
          <Card className="p-4">
            <div className="text-2xl font-bold text-yellow-600">
              {orders.filter((o) => o.status === "processing").length}
            </div>
            <p className="text-gray-600 text-sm">قيد المعالجة</p>
          </Card>
          <Card className="p-4">
            <div className="text-2xl font-bold text-green-600">
              {orders.filter((o) => o.status === "completed").length}
            </div>
            <p className="text-gray-600 text-sm">مكتملة</p>
          </Card>
          <Card className="p-4">
            <div className="text-2xl font-bold text-blue-600">
              {orders.filter((o) => o.status === "received").length}
            </div>
            <p className="text-gray-600 text-sm">جديدة</p>
          </Card>
        </div>

        {/* Orders Table */}
        <Card className="overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-100 border-b">
                <tr>
                  <th className="px-6 py-3 text-right text-sm font-bold text-gray-700">اسم العميل</th>
                  <th className="px-6 py-3 text-right text-sm font-bold text-gray-700">البريد الإلكتروني</th>
                  <th className="px-6 py-3 text-right text-sm font-bold text-gray-700">الخدمة</th>
                  <th className="px-6 py-3 text-right text-sm font-bold text-gray-700">الحالة</th>
                  <th className="px-6 py-3 text-right text-sm font-bold text-gray-700">التاريخ</th>
                  <th className="px-6 py-3 text-right text-sm font-bold text-gray-700">الإجراءات</th>
                </tr>
              </thead>
              <tbody>
                {orders.map((order) => (
                  <tr key={order.id} className="border-b hover:bg-gray-50 transition">
                    <td className="px-6 py-4 text-sm text-gray-900">{order.userName}</td>
                    <td className="px-6 py-4 text-sm text-gray-600">{order.userEmail}</td>
                    <td className="px-6 py-4 text-sm text-gray-900">{order.serviceType}</td>
                    <td className="px-6 py-4">
                      <Badge className={`flex items-center gap-2 w-fit ${getStatusColor(order.status)}`}>
                        {getStatusIcon(order.status)}
                        {getStatusLabel(order.status)}
                      </Badge>
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-600">{formatDate(order.createdAt)}</td>
                    <td className="px-6 py-4 text-sm">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setSelectedOrder(order)}
                        className="text-[#7B68EE] border-[#7B68EE] hover:bg-[#7B68EE] hover:text-white"
                      >
                        عرض التفاصيل
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>

        {/* Order Details Modal */}
        {selectedOrder && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <Card className="w-full max-w-2xl max-h-[90vh] overflow-y-auto">
              <div className="p-6">
                <div className="flex justify-between items-start mb-6">
                  <h2 className="text-2xl font-bold">تفاصيل الطلب #{selectedOrder.id}</h2>
                  <button
                    onClick={() => setSelectedOrder(null)}
                    className="text-gray-500 hover:text-gray-700 text-2xl"
                  >
                    ✕
                  </button>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-bold text-gray-700 mb-1">اسم العميل</label>
                    <p className="text-gray-900">{selectedOrder.userName}</p>
                  </div>

                  <div>
                    <label className="block text-sm font-bold text-gray-700 mb-1">البريد الإلكتروني</label>
                    <p className="text-gray-900">{selectedOrder.userEmail}</p>
                  </div>

                  <div>
                    <label className="block text-sm font-bold text-gray-700 mb-1">الخدمة</label>
                    <p className="text-gray-900">{selectedOrder.serviceType}</p>
                  </div>

                  <div>
                    <label className="block text-sm font-bold text-gray-700 mb-1">التفاصيل</label>
                    <p className="text-gray-900 bg-gray-50 p-3 rounded">{selectedOrder.details}</p>
                  </div>

                  <div>
                    <label className="block text-sm font-bold text-gray-700 mb-1">الحالة</label>
                    <Badge className={`w-fit ${getStatusColor(selectedOrder.status)}`}>
                      {getStatusLabel(selectedOrder.status)}
                    </Badge>
                  </div>

                  <div>
                    <label className="block text-sm font-bold text-gray-700 mb-1">التاريخ</label>
                    <p className="text-gray-900">{formatDate(selectedOrder.createdAt)}</p>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex gap-2 pt-4 border-t">
                    {selectedOrder.status === "received" && (
                      <Button
                        className="flex-1 bg-yellow-600 hover:bg-yellow-700 text-white"
                        onClick={() => {
                          toast.success("تم تحديث الحالة إلى قيد المعالجة");
                          setSelectedOrder(null);
                        }}
                      >
                        بدء المعالجة
                      </Button>
                    )}

                    {selectedOrder.status === "processing" && (
                      <>
                        <Button
                          className="flex-1 bg-green-600 hover:bg-green-700 text-white"
                          onClick={() => {
                            toast.success("تم تحديث الحالة إلى مكتمل");
                            setSelectedOrder(null);
                          }}
                        >
                          <CheckCircle2 className="w-4 h-4 ml-2" />
                          تحديث مكتمل
                        </Button>
                        <Button
                          className="flex-1 bg-red-600 hover:bg-red-700 text-white"
                          onClick={() => {
                            toast.error("تم تحديث الحالة إلى فشل");
                            setSelectedOrder(null);
                          }}
                        >
                          <AlertCircle className="w-4 h-4 ml-2" />
                          تحديث فشل
                        </Button>
                      </>
                    )}

                    {selectedOrder.status === "completed" && (
                      <Button
                        className="flex-1 bg-blue-600 hover:bg-blue-700 text-white"
                        onClick={() => {
                          toast.success("تم تحميل الملف");
                        }}
                      >
                        <Download className="w-4 h-4 ml-2" />
                        تحميل الملف
                      </Button>
                    )}

                    <Button
                      variant="outline"
                      className="flex-1"
                      onClick={() => setSelectedOrder(null)}
                    >
                      إغلاق
                    </Button>
                  </div>
                </div>
              </div>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}
