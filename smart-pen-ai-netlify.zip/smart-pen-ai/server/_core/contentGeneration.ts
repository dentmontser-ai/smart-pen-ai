/**
 * Content Generation Module
 * استخدام نموذج محلي مجاني لتوليد المحتوى الأكاديمي
 * يستخدم Ollama أو نموذج مفتوح المصدر بدون تكاليف
 */

export type ContentType = "research" | "presentation" | "summary" | "exam_solution" | "essay" | "outline";

export interface ContentGenerationRequest {
  serviceType: string;
  language: string;
  details: string;
  contentType: ContentType;
}

export interface GeneratedContent {
  title: string;
  content: string;
  sections: Section[];
}

export interface Section {
  title: string;
  content: string;
  subsections?: string[];
}

/**
 * توليد محتوى أكاديمي باستخدام نموذج محلي
 * يمكن استخدام Ollama أو أي نموذج LLM محلي
 */
export async function generateAcademicContent(
  request: ContentGenerationRequest
): Promise<GeneratedContent> {
  try {
    // محاكاة توليد محتوى أكاديمي
    // في الإنتاج، يمكن استخدام Ollama أو نموذج آخر
    const generatedContent = generateMockContent(request);
    return generatedContent;
  } catch (error) {
    console.error("Error generating academic content:", error);
    throw new Error("Failed to generate academic content");
  }
}

/**
 * توليد محتوى وهمي للاختبار
 * يمكن استبداله بنموذج حقيقي لاحقاً
 */
function generateMockContent(request: ContentGenerationRequest): GeneratedContent {
  const { serviceType, language, details, contentType } = request;

  const isArabic = language.includes("عربي");
  const prefix = isArabic ? "محتوى أكاديمي: " : "Academic Content: ";
  const sectionPrefix = isArabic ? "القسم" : "Section";

  let title = "";
  let content = "";
  let sections: Section[] = [];

  // توليد محتوى مختلف حسب نوع الخدمة
  switch (contentType) {
    case "research":
      title = `${prefix}بحث علمي - ${serviceType}`;
      sections = generateResearchSections(isArabic, details);
      break;

    case "presentation":
      title = `${prefix}عرض تقديمي - ${serviceType}`;
      sections = generatePresentationSections(isArabic, details);
      break;

    case "summary":
      title = `${prefix}ملخص - ${serviceType}`;
      sections = generateSummarySections(isArabic, details);
      break;

    case "exam_solution":
      title = `${prefix}حل اختبار - ${serviceType}`;
      sections = generateExamSolutions(isArabic, details);
      break;

    case "essay":
      title = `${prefix}مقالة - ${serviceType}`;
      sections = generateEssaySections(isArabic, details);
      break;

    case "outline":
      title = `${prefix}مخطط - ${serviceType}`;
      sections = generateOutlineSections(isArabic, details);
      break;
  }

  content = sections.map((s) => `${s.title}\n${s.content}`).join("\n\n");

  return {
    title,
    content,
    sections,
  };
}

function generateResearchSections(isArabic: boolean, details: string): Section[] {
  return [
    {
      title: isArabic ? "المقدمة" : "Introduction",
      content: isArabic
        ? `هذا البحث يتناول موضوع: ${details}. سيتم استعراض أهم الدراسات والأبحاث السابقة المتعلقة بهذا الموضوع.`
        : `This research addresses the topic: ${details}. We will review the most important previous studies and research related to this topic.`,
    },
    {
      title: isArabic ? "الدراسات السابقة" : "Literature Review",
      content: isArabic
        ? "تم مراجعة عدد من الدراسات الحديثة والقديمة ذات الصلة بالموضوع، مما يساهم في فهم أعمق للمشكلة."
        : "Several recent and older studies related to the topic have been reviewed, contributing to a deeper understanding of the problem.",
    },
    {
      title: isArabic ? "المنهجية" : "Methodology",
      content: isArabic
        ? "تم استخدام المنهج العلمي في جمع البيانات وتحليلها بشكل دقيق ومنطقي."
        : "The scientific method was used to collect and analyze data accurately and logically.",
    },
    {
      title: isArabic ? "النتائج" : "Results",
      content: isArabic
        ? "توصل البحث إلى عدة نتائج مهمة تساهم في فهم الموضوع بشكل أفضل."
        : "The research reached several important results that contribute to a better understanding of the topic.",
    },
    {
      title: isArabic ? "الخلاصة" : "Conclusion",
      content: isArabic
        ? "يمكن الخلوص إلى أن هذا الموضوع يحتاج إلى مزيد من الدراسة والبحث."
        : "It can be concluded that this topic requires further study and research.",
    },
  ];
}

function generatePresentationSections(isArabic: boolean, details: string): Section[] {
  return [
    {
      title: isArabic ? "الشريحة الأولى: العنوان" : "Slide 1: Title",
      content: details,
      subsections: [
        isArabic ? "اسم المقدم" : "Presenter Name",
        isArabic ? "التاريخ" : "Date",
      ],
    },
    {
      title: isArabic ? "الشريحة الثانية: المحتوى الرئيسي" : "Slide 2: Main Content",
      content: isArabic ? "النقاط الرئيسية للموضوع" : "Main points of the topic",
      subsections: [
        isArabic ? "النقطة الأولى" : "Point 1",
        isArabic ? "النقطة الثانية" : "Point 2",
        isArabic ? "النقطة الثالثة" : "Point 3",
      ],
    },
    {
      title: isArabic ? "الشريحة الثالثة: التفاصيل" : "Slide 3: Details",
      content: isArabic ? "تفاصيل إضافية مهمة" : "Important additional details",
    },
    {
      title: isArabic ? "الشريحة الأخيرة: الخلاصة" : "Final Slide: Conclusion",
      content: isArabic ? "ملخص النقاط الرئيسية" : "Summary of main points",
    },
  ];
}

function generateSummarySections(isArabic: boolean, details: string): Section[] {
  return [
    {
      title: isArabic ? "الملخص التنفيذي" : "Executive Summary",
      content: isArabic
        ? `ملخص شامل للموضوع: ${details}`
        : `Comprehensive summary of the topic: ${details}`,
    },
    {
      title: isArabic ? "النقاط الرئيسية" : "Key Points",
      content: isArabic
        ? "1. النقطة الأولى\n2. النقطة الثانية\n3. النقطة الثالثة"
        : "1. First point\n2. Second point\n3. Third point",
    },
    {
      title: isArabic ? "الاستنتاجات" : "Conclusions",
      content: isArabic
        ? "الاستنتاجات المهمة من هذا الملخص"
        : "Important conclusions from this summary",
    },
  ];
}

function generateExamSolutions(isArabic: boolean, details: string): Section[] {
  return [
    {
      title: isArabic ? "السؤال الأول" : "Question 1",
      content: isArabic ? `السؤال: ${details}` : `Question: ${details}`,
      subsections: [
        isArabic ? "الإجابة الصحيحة" : "Correct Answer",
        isArabic ? "الشرح" : "Explanation",
      ],
    },
    {
      title: isArabic ? "السؤال الثاني" : "Question 2",
      content: isArabic ? "محتوى السؤال" : "Question content",
      subsections: [
        isArabic ? "الإجابة" : "Answer",
        isArabic ? "التوضيح" : "Clarification",
      ],
    },
    {
      title: isArabic ? "السؤال الثالث" : "Question 3",
      content: isArabic ? "محتوى السؤال" : "Question content",
      subsections: [
        isArabic ? "الإجابة" : "Answer",
        isArabic ? "التوضيح" : "Clarification",
      ],
    },
  ];
}

function generateEssaySections(isArabic: boolean, details: string): Section[] {
  return [
    {
      title: isArabic ? "المقدمة" : "Introduction",
      content: isArabic
        ? `موضوع المقالة: ${details}`
        : `Essay topic: ${details}`,
    },
    {
      title: isArabic ? "الجسم الأول" : "Body Paragraph 1",
      content: isArabic
        ? "الفقرة الأولى من جسم المقالة مع تفاصيل مهمة"
        : "First paragraph of the essay body with important details",
    },
    {
      title: isArabic ? "الجسم الثاني" : "Body Paragraph 2",
      content: isArabic
        ? "الفقرة الثانية من جسم المقالة"
        : "Second paragraph of the essay body",
    },
    {
      title: isArabic ? "الخاتمة" : "Conclusion",
      content: isArabic
        ? "خاتمة المقالة مع إعادة صياغة الأفكار الرئيسية"
        : "Essay conclusion with restatement of main ideas",
    },
  ];
}

function generateOutlineSections(isArabic: boolean, details: string): Section[] {
  return [
    {
      title: isArabic ? "العنوان الرئيسي" : "Main Title",
      content: details,
      subsections: [
        isArabic ? "1. القسم الأول" : "1. First Section",
        isArabic ? "2. القسم الثاني" : "2. Second Section",
        isArabic ? "3. القسم الثالث" : "3. Third Section",
      ],
    },
    {
      title: isArabic ? "التفاصيل" : "Details",
      content: isArabic
        ? "تفاصيل شاملة لكل قسم من الأقسام"
        : "Comprehensive details for each section",
    },
  ];
}

/**
 * تحويل المحتوى المُولّد إلى نص عادي
 */
export function convertToPlainText(content: GeneratedContent): string {
  let text = `${content.title}\n${"=".repeat(content.title.length)}\n\n`;

  content.sections.forEach((section) => {
    text += `${section.title}\n${"-".repeat(section.title.length)}\n`;
    text += `${section.content}\n`;

    if (section.subsections && section.subsections.length > 0) {
      text += "\n";
      section.subsections.forEach((sub) => {
        text += `• ${sub}\n`;
      });
    }

    text += "\n";
  });

  return text;
}
