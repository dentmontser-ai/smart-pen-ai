/**
 * File Generation Module
 * توليد ملفات Word و PowerPoint و PDF من المحتوى المُولّد
 */

import { Document, Packer, Paragraph, TextRun, HeadingLevel } from "docx";
import PDFDocument from "pdfkit";
import { GeneratedContent } from "./contentGeneration";
import { storagePut } from "../storage";

export interface FileGenerationRequest {
  content: GeneratedContent;
  format: "docx" | "pdf" | "pptx";
  language: string;
  orderId: number;
}

/**
 * توليد ملف Word (DOCX)
 */
export async function generateWordDocument(
  content: GeneratedContent,
  language: string,
  orderId: number
): Promise<{ url: string; key: string }> {
  try {
    const isArabic = language.includes("عربي");

    // بناء المستند
    const sections = content.sections.map((section) => [
      new Paragraph({
        text: section.title,
        heading: HeadingLevel.HEADING_1,
        run: { bold: true },
        spacing: { after: 200 },
      }),
      new Paragraph({
        text: section.content,
        spacing: { after: 200 },
      }),
      ...(section.subsections
        ? section.subsections.map(
            (sub) =>
              new Paragraph({
                text: `• ${sub}`,
                spacing: { after: 100 },
              })
          )
        : []),
    ]);

    const doc = new Document({
      sections: [
        {
          children: [
            new Paragraph({
              text: content.title,
              heading: HeadingLevel.HEADING_1,
              run: { bold: true },
              spacing: { after: 400 },
            }),
            ...sections.flat(),
          ],
        },
      ],
    });

    // تحويل إلى Buffer
    const buffer = await Packer.toBuffer(doc);

    // رفع إلى السحابة
    const fileName = `order-${orderId}-${Date.now()}.docx`;
    const result = await storagePut(
      `academic-content/${fileName}`,
      buffer,
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    );

    return result;
  } catch (error) {
    console.error("Error generating Word document:", error);
    throw error;
  }
}

/**
 * توليد ملف PDF
 */
export async function generatePDFDocument(
  content: GeneratedContent,
  language: string,
  orderId: number
): Promise<{ url: string; key: string }> {
  try {
    const isArabic = language.includes("عربي");

    return new Promise(async (resolve, reject) => {
      try {
        const doc = new PDFDocument({
          bufferPages: true,
          margin: 50,
        });

        // جمع البيانات في Buffer
        const chunks: Buffer[] = [];
        doc.on("data", (chunk: Buffer) => chunks.push(chunk));

        // العنوان
        doc.fontSize(24).font("Helvetica-Bold").text(content.title, { align: "center" });
        doc.moveDown();

        // الأقسام
        content.sections.forEach((section) => {
          doc.fontSize(14).font("Helvetica-Bold").text(section.title);
          doc.moveDown(0.5);

          doc.fontSize(11).font("Helvetica").text(section.content);
          doc.moveDown();

          if (section.subsections) {
            section.subsections.forEach((sub) => {
              doc.fontSize(10).text(`• ${sub}`);
            });
            doc.moveDown();
          }
        });

        // إنهاء المستند
        doc.end();

        // انتظار انتهاء الكتابة
        doc.on("end", async () => {
          try {
            const buffer = Buffer.concat(chunks);

            // رفع إلى السحابة
            const fileName = `order-${orderId}-${Date.now()}.pdf`;
            const result = await storagePut(
              `academic-content/${fileName}`,
              buffer,
              "application/pdf"
            );

            resolve(result);
          } catch (error) {
            reject(error);
          }
        });
      } catch (error) {
        reject(error);
      }
    });
  } catch (error) {
    console.error("Error generating PDF document:", error);
    throw error;
  }
}

/**
 * توليد ملف PowerPoint (PPTX)
 * ملاحظة: يتطلب مكتبة إضافية مثل pptxgen
 */
export async function generatePowerPointPresentation(
  content: GeneratedContent,
  language: string,
  orderId: number
): Promise<{ url: string; key: string }> {
  try {
    // في الإنتاج، يمكن استخدام مكتبة pptxgen
    // للآن، سنرجع ملف PDF كبديل مؤقت
    console.warn(
      "PowerPoint generation not yet implemented, returning PDF instead"
    );
    return generatePDFDocument(content, language, orderId);
  } catch (error) {
    console.error("Error generating PowerPoint presentation:", error);
    throw error;
  }
}

/**
 * توليد الملف بناءً على الصيغة المطلوبة
 */
export async function generateFile(
  request: FileGenerationRequest
): Promise<{ url: string; key: string }> {
  switch (request.format) {
    case "docx":
      return generateWordDocument(request.content, request.language, request.orderId);
    case "pdf":
      return generatePDFDocument(request.content, request.language, request.orderId);
    case "pptx":
      return generatePowerPointPresentation(request.content, request.language, request.orderId);
    default:
      throw new Error(`Unsupported file format: ${request.format}`);
  }
}
