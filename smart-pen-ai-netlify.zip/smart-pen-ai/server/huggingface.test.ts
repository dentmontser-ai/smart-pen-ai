import { describe, it, expect } from "vitest";

/**
 * Test to verify Hugging Face API key is valid and working
 */
describe("Hugging Face API Integration", () => {
  it("should validate Hugging Face API key by checking authentication", async () => {
    const apiKey = process.env.HUGGING_FACE_API_KEY;
    
    if (!apiKey) {
      throw new Error("HUGGING_FACE_API_KEY environment variable is not set");
    }

    // Verify the API key format
    expect(apiKey).toMatch(/^hf_/);
    expect(apiKey.length).toBeGreaterThan(20);

    try {
      // Call Hugging Face API to validate the key
      const response = await fetch(
        "https://huggingface.co/api/whoami",
        {
          method: "GET",
          headers: {
            Authorization: `Bearer ${apiKey}`,
          },
        }
      );

      // If we get a 401 or 403, the API key is invalid
      if (response.status === 401 || response.status === 403) {
        throw new Error("Invalid Hugging Face API key - Authentication failed");
      }

      // Check if the response is successful
      expect(response.ok).toBe(true);
      
      const data = await response.json();
      
      // If we got a valid response with user info, the API key works
      expect(data).toBeDefined();
      expect(typeof data).toBe("object");
      
      console.log("✅ Hugging Face API key is valid and working!");
      console.log(`✅ Authenticated as: ${data.name || data.username || "User"}`);
    } catch (error) {
      console.error("❌ Hugging Face API validation failed:", error);
      throw error;
    }
  });
});
