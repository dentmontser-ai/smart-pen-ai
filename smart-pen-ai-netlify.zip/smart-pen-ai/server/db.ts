import { eq, desc } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, orders, generatedContent, files, orderStatusHistory, Order, InsertOrder, GeneratedContent, InsertGeneratedContent, File, InsertFile } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// ===== Order Management Functions =====

export async function createOrder(orderData: InsertOrder): Promise<Order | null> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot create order: database not available");
    return null;
  }

  try {
    const result = await db.insert(orders).values(orderData);
    const orderId = (result as any)[0]?.insertId;
    if (!orderId) return null;
    const createdOrder = await db.select().from(orders).where(eq(orders.id, Number(orderId))).limit(1);
    return createdOrder.length > 0 ? createdOrder[0] : null;
  } catch (error) {
    console.error("[Database] Failed to create order:", error);
    throw error;
  }
}

export async function getOrderById(orderId: number): Promise<Order | null> {
  const db = await getDb();
  if (!db) return null;

  const result = await db.select().from(orders).where(eq(orders.id, orderId)).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function getAllOrders(limit: number = 50, offset: number = 0): Promise<Order[]> {
  const db = await getDb();
  if (!db) return [];

  return db.select().from(orders).orderBy(desc(orders.createdAt)).limit(limit).offset(offset);
}

export async function updateOrderStatus(orderId: number, newStatus: "received" | "processing" | "completed" | "failed", reason?: string): Promise<boolean> {
  const db = await getDb();
  if (!db) return false;

  try {
    const currentOrder = await getOrderById(orderId);
    if (!currentOrder) return false;

    await db.update(orders).set({ status: newStatus }).where(eq(orders.id, orderId));
    await db.insert(orderStatusHistory).values({
      orderId,
      previousStatus: currentOrder.status,
      newStatus,
      reason,
    });

    return true;
  } catch (error) {
    console.error("[Database] Failed to update order status:", error);
    return false;
  }
}

// ===== Generated Content Functions =====

export async function saveGeneratedContent(contentData: InsertGeneratedContent): Promise<GeneratedContent | null> {
  const db = await getDb();
  if (!db) return null;

  try {
    const result = await db.insert(generatedContent).values(contentData);
    const contentId = (result as any)[0]?.insertId;
    if (!contentId) return null;
    const savedContent = await db.select().from(generatedContent).where(eq(generatedContent.id, Number(contentId))).limit(1);
    return savedContent.length > 0 ? savedContent[0] : null;
  } catch (error) {
    console.error("[Database] Failed to save generated content:", error);
    throw error;
  }
}

export async function getContentByOrderId(orderId: number): Promise<GeneratedContent | null> {
  const db = await getDb();
  if (!db) return null;

  const result = await db.select().from(generatedContent).where(eq(generatedContent.orderId, orderId)).limit(1);
  return result.length > 0 ? result[0] : null;
}

// ===== File Management Functions =====

export async function saveFileRecord(fileData: InsertFile): Promise<File | null> {
  const db = await getDb();
  if (!db) return null;

  try {
    const result = await db.insert(files).values(fileData);
    const fileId = (result as any)[0]?.insertId;
    if (!fileId) return null;
    const savedFile = await db.select().from(files).where(eq(files.id, Number(fileId))).limit(1);
    return savedFile.length > 0 ? savedFile[0] : null;
  } catch (error) {
    console.error("[Database] Failed to save file record:", error);
    throw error;
  }
}

export async function getFilesByOrderId(orderId: number): Promise<File[]> {
  const db = await getDb();
  if (!db) return [];

  return db.select().from(files).where(eq(files.orderId, orderId));
}

// TODO: add more feature queries here as your schema grows.
