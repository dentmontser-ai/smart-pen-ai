import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { createOrder, updateOrderStatus } from "./db";
import { notifyOwner } from "./_core/notification";

export const appRouter = router({
  // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  orders: router({
    submitOrder: publicProcedure
      .input(
        z.object({
          serviceType: z.string().min(1),
          language: z.string().min(1),
          fileFormat: z.string().min(1),
          details: z.string().min(1),
          userName: z.string().min(1),
          userEmail: z.string().email(),
          userPhone: z.string().min(1),
          attachmentFileName: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        try {
          const order = await createOrder({
            serviceType: input.serviceType,
            language: input.language,
            fileFormat: input.fileFormat,
            details: input.details,
            userName: input.userName,
            userEmail: input.userEmail,
            userPhone: input.userPhone,
            attachmentFileName: input.attachmentFileName,
            status: "received",
          });

          if (order) {
            // Update status to processing
            await updateOrderStatus(order.id, "processing", "تم استقبال الطلب وجاري المعالجة");

            // Notify owner
            await notifyOwner({
              title: `طلب جديد من ${input.userName}`,
              content: `تم استقبال طلب جديد:\n\nالخدمة: ${input.serviceType}\nاللغة: ${input.language}\nصيغة الملف: ${input.fileFormat}\nالبريد: ${input.userEmail}\nالهاتف: ${input.userPhone}\n\nالتفاصيل:\n${input.details}`,
            });
          }

          return order;
        } catch (error) {
          console.error("Error submitting order:", error);
          throw error;
        }
      }),
  }),
});

export type AppRouter = typeof appRouter;
